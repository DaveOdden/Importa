<?php include_once ("../../common/app_header.php"); ?>
<?php include_once ("../../common/app_nav.php"); ?>
<h3>Woot's Deal of the Day</h3>
<hr/>
<iframe src="http://woot.com" width="100%" height="100%" scrolling="no"></iframe>
<?php include_once ("../../common/app_footer.php"); ?>