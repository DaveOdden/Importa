<?php include_once ("app_functions.php"); ?>
<?php include_once ("../../common/app_header.php"); ?>

<?php
session_start();
//if a session is active, proceed to 
if (!isset($_SESSION['SESS_USERNAME']))
{
	?>
	<script type="text/javascript">
	<!--
	window.location = "../../login.php"
	//-->
	</script>
	<?php
}

?>
<?php require ("../../common/app_nav.php"); ?>
		<h3>Monetrac</h3>
		<hr id="hr_adj"/>
		<?php
		$username = $_SESSION['SESS_USERNAME'];
		$user_data = mysql_query("SELECT user_data FROM Monetrac WHERE username = '$username'");
		while($info = mysql_fetch_array( $user_data )) 
		{
			$_SESSION['user_data'] = $info['user_data'];
		}
		$user_data = $_SESSION['user_data'];
		
		?>
		<table border="1">
			<tr>
			<th> </th>
			<th>Jan.</th>
			<th>Feb.</th>
			<th>March</th>
			<th>April</th>
			<th>May</th>
			<th>June</th>
			<th>July</th>
			<th>Aug.</th>
			<th>Sept.</th>
			<th>Oct.</th>
			<th>Nov.</th>
			<th>Dec.</th>
			</tr>
		<tr>
		<td>Entertainment&nbsp;&nbsp;&nbsp;</td>
		<td class="edit"><?php echo $user_data ?></td>
		<?php
		while($info = mysql_fetch_array( $user_data )) 
		{
			$_SESSION['user_data'] = $info['user_data'];
		}
		?>
		</tr>
		<tr>
		<td>Gas&nbsp;&nbsp;&nbsp;</td>
		<td class="edit"><?php echo $user_data ?></td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		
		</tr>
		<tr>
		<td>Rent/Utilities&nbsp;&nbsp;&nbsp;</td>
		<td class="edit"><?php echo $user_data ?></td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		<td>-</td>
		
		</tr>
		</table>
		<a href="#" class="add_cat">Add Category</a>
		<script type="text/javascript">
		$(document).ready(function () {
			
			$('.edit').editable('http://localhost:8888/webapp/apps/Monetrac/save_table_data.php', {
			         indicator: 'Saving',
			         tooltip  : 'Click to edit...',
					 name     : 'value',
					 cssclass : 'someclass'
			     }); 
		});
		</script>
<?php include_once ("../../common/footer.php"); ?>