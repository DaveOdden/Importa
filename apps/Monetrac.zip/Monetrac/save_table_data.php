<?php
$con = mysql_connect('localhost', 'root', 'root');

if (!$con)
{
die('Could not connect: ' . mysql_error());
}
mysql_select_db("webapp", $con);
session_start();


$user_data = $_POST['value'];
$g = mysql_query("INSERT INTO Monetrac (username, user_categories, user_data)
			VALUES ('".$_SESSION['SESS_USERNAME']."', 'test', '".$_POST['value']."')");
			
echo $user_data;
?>